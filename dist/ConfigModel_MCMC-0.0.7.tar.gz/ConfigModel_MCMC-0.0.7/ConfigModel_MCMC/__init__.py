name = "ConfigModel_MCMC"

__version__ = '0.0.7'
__authors__ = 'Upasana Dutta; Bailey K. Fosdick; Aaron Clauset'

from .ConfigModel_MCMC import MCMC