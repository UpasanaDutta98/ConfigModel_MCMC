name = "ConfigModel_MCMC"

__version__ = '0.0.2'
__authors__ = 'Upasana Dutta; Aaron Clauset'

from .ConfigModel_MCMC import MCMC