name = "ConfigModel_MCMC"

__version__ = '0.2'
__authors__ = 'Upasana Dutta'

from .ConfigModel_MCMC import MCMC